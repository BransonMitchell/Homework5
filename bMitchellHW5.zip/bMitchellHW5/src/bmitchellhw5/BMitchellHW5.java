package bmitchellhw5;
import java.util.*;
import java.io.*;

/**
 * This program will read a file into the program from user input. Then separate the words into two arraylists and one linked list. One arraylist will contain all of the text in the file,
 * the other arraylist will contain only unique words from the file. Then it will compare the two array lists to tell you how many times a given word appears in the document. Finally It will sort the lists.
 * @author Branson Mitchell
 */
public class BMitchellHW5 
{

    public static void main(String[] args) throws IOException
    {
        Scanner fileInput = new Scanner(System.in);
        System.out.print("Filename:");
        String fileName = fileInput.nextLine();
        File file = new File(fileName);
        Scanner readFile = new Scanner(file);
        BufferedWriter outputFile = new BufferedWriter(new FileWriter(new File("HW5.txt")));
        
        //test whether file has been read in correctly
        //while(readFile.hasNext())
        //{
        //    System.out.print(readFile.next());
        //}
        
        ArrayList<String> bookArrayList = new ArrayList<String>();
        LinkedList<String> bookList = new LinkedList<String>();
        ArrayList<String> uniqueWords = new ArrayList<String>();
        while(readFile.hasNext())
        {
            String noSpecial = readFile.next().replaceAll("[^a-zA-Z0-9']"," ");
            if(!bookArrayList.contains(noSpecial))
            {
                uniqueWords.add(noSpecial.toLowerCase());
            }
            bookArrayList.add(noSpecial.toLowerCase());
            bookList.add(noSpecial.toLowerCase());
        }
        //test to make sure array list is filled
        //System.out.println(bookArrayList.size())
        
        System.out.println("Number of unique words: " + uniqueWords.size());
        //This nested for loop tests each unique word against all the words in the original document 
        //to see how many times each word appears.
        for(String s : uniqueWords)
        {
            StringBuilder wordCount = new StringBuilder();
            int count = 0;
            for(String word : bookArrayList)
            {
                if(s.equals(word))
                {
                    count++;
                }
            }
            wordCount.append(count);
            //test that it works
            //System.out.println(s + " " + wordCount);
            
            outputFile.write("\n" + s + " " + wordCount + "\n");
            outputFile.newLine();
        }
        
        bookArrayList.sort(null);
        uniqueWords.sort(null);
        bookList.sort(null);
       
        outputFile.flush();
        outputFile.close();
        
    }
    
}
